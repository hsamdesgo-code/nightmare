/**
 * NIGHTMARE — Fullscreen API Manager
 * Only toggles fullscreen on explicit user click/tap.
 * Gracefully hides/adapts when Fullscreen API is unavailable (e.g., iPhone Safari).
 */
(function (global) {
  'use strict';

  class FullscreenManager {
    constructor(buttonEl, labelEl) {
      this.button = buttonEl;
      this.label = labelEl;
      this.targetEl = document.documentElement;
      this.supported = this.checkSupport();

      this.syncUI();
      if (this.supported) {
        document.addEventListener('fullscreenchange', () => this.syncUI());
        document.addEventListener('webkitfullscreenchange', () => this.syncUI());
      }
    }

    checkSupport() {
      const doc = document;
      const enabled = doc.fullscreenEnabled ?? doc.webkitFullscreenEnabled;
      const hasRequest = Boolean(
        this.targetEl.requestFullscreen || this.targetEl.webkitRequestFullscreen
      );
      return Boolean(enabled !== false && hasRequest);
    }

    isFullscreen() {
      return Boolean(document.fullscreenElement || document.webkitFullscreenElement);
    }

    async toggle() {
      if (!this.supported) return false;

      try {
        if (this.isFullscreen()) {
          if (document.exitFullscreen) {
            await document.exitFullscreen();
          } else if (document.webkitExitFullscreen) {
            document.webkitExitFullscreen();
          }
        } else {
          if (this.targetEl.requestFullscreen) {
            await this.targetEl.requestFullscreen({ navigationUI: 'hide' });
          } else if (this.targetEl.webkitRequestFullscreen) {
            this.targetEl.webkitRequestFullscreen();
          }
        }
      } catch (_) {
        // Browser blocked or unavailable in current embed context; viewport still fills 100dvh
      }
      this.syncUI();
      return this.isFullscreen();
    }

    syncUI() {
      if (!this.button) return;
      if (!this.supported) {
        this.button.classList.add('is-unsupported');
        this.button.setAttribute('aria-hidden', 'true');
        return;
      }

      const active = this.isFullscreen();
      this.button.classList.toggle('is-fullscreen', active);
      this.button.setAttribute('aria-pressed', active ? 'true' : 'false');
      this.button.setAttribute('aria-label', active ? 'Exit fullscreen' : 'Enter fullscreen');
      if (this.label) {
        this.label.textContent = active ? 'EXIT FULL' : 'FULLSCREEN';
      }
    }
  }

  global.NightmareFullscreen = FullscreenManager;
})(window);
