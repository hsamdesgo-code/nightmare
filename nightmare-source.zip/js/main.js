/**
 * NIGHTMARE — Application Bootstrap
 */
(function () {
  'use strict';

  function init() {
    const params = new URLSearchParams(window.location.search);
    const fastMode = params.get('fast') === '1';
    const requestedStage = Number(params.get('stage') || '1');
    const startStage = Number.isInteger(requestedStage) && requestedStage >= 1 && requestedStage <= 5
      ? requestedStage
      : 1;

    const elements = {
      appShell: document.getElementById('app'),
      metaThemeColor: document.getElementById('meta-theme-color'),
      ambientCanvas: document.getElementById('ambient-canvas'),
      confettiCanvas: document.getElementById('confetti-canvas'),
      fxBlackout: document.getElementById('fx-blackout'),

      audioBtn: document.getElementById('btn-audio'),
      audioLabel: document.getElementById('audio-label'),
      fsBtn: document.getElementById('btn-fullscreen'),
      fsLabel: document.getElementById('fs-label'),

      stageTerminal: document.getElementById('stage-terminal'),
      stageWarning: document.getElementById('stage-warning'),
      stageBreach: document.getElementById('stage-breach'),
      stageReveal: document.getElementById('stage-reveal'),

      statusPill: document.getElementById('terminal-status-pill'),
      chromeHex: document.getElementById('chrome-hex'),
      terminalLog: document.getElementById('terminal-log'),
      progressCaption: document.getElementById('progress-caption'),
      progressPercent: document.getElementById('progress-percent'),
      progressTrack: document.getElementById('progress-track'),
      progressFill: document.getElementById('progress-fill'),

      countdownNumber: document.getElementById('countdown-number'),
      countdownArc: document.getElementById('countdown-arc'),
      warningTickerText: document.getElementById('warning-ticker-text'),

      breachAlert: document.getElementById('breach-alert'),

      btnGotMe: document.getElementById('btn-got-me'),
      btnGotMeText: document.getElementById('btn-got-me-text'),
      revealPostNote: document.getElementById('reveal-post-note'),
      revealEmojiRing: document.getElementById('reveal-emoji-ring'),
      btnReplay: document.getElementById('btn-replay'),
      btnShare: document.getElementById('btn-share'),
      btnShareLabel: document.getElementById('btn-share-label')
    };

    const audio = new window.NightmareAudio();
    const effects = new window.NightmareEffects(elements.ambientCanvas, elements.confettiCanvas);
    const fullscreen = new window.NightmareFullscreen(elements.fsBtn, elements.fsLabel);
    const experience = new window.NightmareExperience(elements, audio, effects, { fast: fastMode });

    function syncAudioButton(isOn) {
      if (!elements.audioBtn) return;
      elements.audioBtn.classList.toggle('is-unmuted', isOn);
      elements.audioBtn.classList.toggle('is-prompting', !isOn && experience.currentStage < 5);
      elements.audioBtn.setAttribute('aria-pressed', isOn ? 'true' : 'false');
      elements.audioBtn.setAttribute('aria-label', isOn ? 'Mute audio effects' : 'Enable audio effects');
      if (elements.audioLabel) {
        elements.audioLabel.textContent = isOn ? 'SOUND ON' : 'SOUND OFF';
      }
    }

    if (elements.audioBtn) {
      elements.audioBtn.addEventListener('click', async () => {
        const active = await audio.toggle();
        syncAudioButton(active);
        if (active && experience.currentStage === 5) {
          audio.playCelebrationPop();
        }
      });
    }

    if (elements.fsBtn) {
      elements.fsBtn.addEventListener('click', () => {
        fullscreen.toggle();
      });
    }

    // Keyboard shortcuts for desktop accessibility (M = audio, F = fullscreen)
    document.addEventListener('keydown', async (event) => {
      if (event.repeat || event.metaKey || event.ctrlKey || event.altKey) return;
      const key = event.key.toLowerCase();
      if (key === 'm') {
        const active = await audio.toggle();
        syncAudioButton(active);
      } else if (key === 'f' && fullscreen.supported) {
        fullscreen.toggle();
      }
    });

    // Offline service worker registration (HTTP/HTTPS only)
    if ('serviceWorker' in navigator && (window.location.protocol === 'https:' || window.location.protocol === 'http:')) {
      navigator.serviceWorker.register('./sw.js').catch(() => {
        // Non-critical if SW registration is unavailable in private/test environments
      });
    }

    // Expose read-only state hook for verification
    window.__NIGHTMARE_STATE__ = {
      getStage: () => experience.currentStage,
      isAudioEnabled: () => audio.isEnabled,
      isFullscreenSupported: () => fullscreen.supported
    };

    syncAudioButton(false);
    experience.start(startStage);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
