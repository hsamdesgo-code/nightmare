/**
 * NIGHTMARE — Stage State Machine & Narrative Controller
 * Drives all 5 cinematic stages deterministically using fictional visual simulations only.
 */
(function (global) {
  'use strict';

  const STAGE_1_LINES = [
    { prefix: '[01]', text: 'Initializing security protocols...', tag: 'OK' },
    { prefix: '[02]', text: 'Establishing encrypted session...', tag: 'OK' },
    { prefix: '[03]', text: 'Analyzing connection...', tag: 'SYNC' },
    { prefix: '[04]', text: 'Running system diagnostics...', tag: 'OK' },
    { prefix: '[05]', text: 'Checking security layers...', tag: 'ACTIVE' }
  ];

  const STAGE_2_STEPS = [
    {
      text: 'SCANNING VIRTUAL ENVIRONMENT...',
      tag: 'SCAN',
      nodeId: 'node-env',
      activeLabel: 'SCANNING',
      doneLabel: 'INDEXED',
      targetProgress: 64,
      delayBefore: 360,
      holdAfter: 650
    },
    {
      text: 'ANALYZING SIMULATED SYSTEM...',
      tag: 'TRACE',
      nodeId: 'node-sys',
      activeLabel: 'PARSING',
      doneLabel: 'MAPPED',
      targetProgress: 81,
      delayBefore: 520,
      holdAfter: 820
    },
    {
      text: 'CHECKING SECURITY STATUS...',
      tag: 'ALERT',
      nodeId: 'node-sec',
      activeLabel: 'PROBING',
      doneLabel: 'EXPOSED',
      targetProgress: 96,
      delayBefore: 440,
      holdAfter: 980
    },
    {
      text: 'ACCESSING DEMONSTRATION ENVIRONMENT...',
      tag: 'LINK',
      nodeId: 'node-demo',
      activeLabel: 'OPENING',
      doneLabel: 'READY',
      targetProgress: 100,
      delayBefore: 580,
      holdAfter: 650
    }
  ];

  const WARNING_TICKERS = [
    'ANOMALY TRACE IN PROGRESS // DO NOT DISCONNECT',
    'SIMULATED FIREWALL INTEGRITY: COMPROMISED',
    'CONTAINMENT OVERRIDE COUNTDOWN ENGAGED',
    'ISOLATION LOCKDOWN SEQUENCE PENDING'
  ];

  const DIAL_CIRCUMFERENCE = 2 * Math.PI * 88; // ~552.92

  class NightmareExperience {
    constructor(elements, audio, effects, options = {}) {
      this.el = elements;
      this.audio = audio;
      this.effects = effects;
      this.speedFactor = options.fast ? 0.22 : 1;

      this.runToken = 0;
      this.timers = new Set();
      this.currentStage = 1;
      this.hasCelebrated = false;
      this.hexCounter = 79;

      this.bindRevealEvents();
    }

    scaleMs(ms) {
      return Math.max(40, Math.round(ms * this.speedFactor));
    }

    schedule(fn, ms) {
      const id = global.setTimeout(() => {
        this.timers.delete(id);
        fn();
      }, ms);
      this.timers.add(id);
      return id;
    }

    clearTimers() {
      this.timers.forEach((id) => global.clearTimeout(id));
      this.timers.clear();
    }

    wait(ms, token) {
      return new Promise((resolve) => {
        this.schedule(() => resolve(token === this.runToken), ms);
      });
    }

    isAlive(token) {
      return token === this.runToken;
    }

    setPhase(phaseName, stageNumber) {
      this.currentStage = stageNumber;
      const body = document.body;
      body.classList.remove(
        'phase-init',
        'phase-scanning',
        'phase-warning',
        'phase-breach',
        'phase-reveal',
        'is-glitching'
      );
      body.classList.add(`phase-${phaseName}`);
      body.dataset.stage = String(stageNumber);

      if (this.el.metaThemeColor) {
        this.el.metaThemeColor.setAttribute(
          'content',
          stageNumber === 5 ? '#f6fffb' : stageNumber >= 3 ? '#140306' : '#030305'
        );
      }

      if (this.el.audioBtn) {
        this.el.audioBtn.classList.toggle('is-prompting', stageNumber < 5 && !this.audio.isEnabled);
      }

      this.audio.setStage(stageNumber);
      this.effects.setMode(phaseName);
    }

    showOnlyStage(stageKey) {
      const stages = {
        terminal: this.el.stageTerminal,
        warning: this.el.stageWarning,
        breach: this.el.stageBreach,
        reveal: this.el.stageReveal
      };

      Object.keys(stages).forEach((key) => {
        const node = stages[key];
        if (!node) return;
        const isActive = key === stageKey;
        node.hidden = !isActive;
        node.classList.toggle('is-active', isActive);
      });
    }

    resetUI() {
      this.hasCelebrated = false;
      this.el.terminalLog.innerHTML = '';
      this.setProgress(0);
      this.el.statusPill.textContent = 'INITIALIZING...';
      this.el.progressCaption.textContent = 'BOOT SEQUENCE ACTIVE';
      this.el.chromeHex.textContent = '0x004F :: SYNC';

      const nodeDefaults = [
        ['node-env', 'STANDBY'],
        ['node-sys', 'STANDBY'],
        ['node-sec', 'WAIT'],
        ['node-demo', 'LOCKED']
      ];
      nodeDefaults.forEach(([id, label]) => {
        const valEl = document.getElementById(id);
        if (!valEl) return;
        valEl.textContent = label;
        valEl.parentElement.classList.remove('is-active', 'is-done');
      });

      this.el.countdownNumber.textContent = '10';
      this.el.countdownArc.style.strokeDasharray = String(DIAL_CIRCUMFERENCE);
      this.el.countdownArc.style.strokeDashoffset = '0';
      this.el.warningTickerText.textContent = WARNING_TICKERS[0];

      this.el.breachAlert.classList.remove('is-visible');
      this.el.fxBlackout.classList.remove('is-blackout', 'is-white-flash');

      this.el.btnGotMe.classList.remove('is-celebrated');
      this.el.btnGotMeText.textContent = 'OKAY, YOU GOT ME 😂';
      this.el.revealPostNote.textContent = '';
      this.el.revealPostNote.classList.remove('is-visible');
      this.el.revealEmojiRing.classList.remove('is-bouncing');

      this.effects.clearConfetti();
    }

    setProgress(targetPercent) {
      const clamped = Math.max(0, Math.min(100, Math.round(targetPercent)));
      this.el.progressFill.style.width = `${clamped}%`;
      this.el.progressPercent.textContent = `${String(clamped).padStart(2, '0')}%`;
      this.el.progressTrack.setAttribute('aria-valuenow', String(clamped));

      this.hexCounter += 17;
      this.el.chromeHex.textContent = `0x${this.hexCounter.toString(16).toUpperCase().padStart(4, '0')} :: LIVE`;
    }

    async animateProgressTo(from, to, durationMs, token) {
      const steps = Math.max(4, Math.round(durationMs / 80));
      const stepTime = durationMs / steps;
      for (let i = 1; i <= steps; i += 1) {
        if (!this.isAlive(token)) return;
        const ratio = i / steps;
        const eased = 1 - Math.pow(1 - ratio, 2);
        this.setProgress(from + (to - from) * eased);
        const ok = await this.wait(stepTime, token);
        if (!ok) return;
      }
    }

    async appendTypedLine({ prefix = '', text, tag, isScan = false }, charDelayMs, token) {
      if (!this.isAlive(token)) return;

      const row = document.createElement('div');
      row.className = `log-line${isScan ? ' is-scan' : ''}`;

      const textSpan = document.createElement('span');
      textSpan.className = 'log-line-text';

      if (prefix) {
        const prefixSpan = document.createElement('span');
        prefixSpan.className = 'log-prefix';
        prefixSpan.textContent = `${prefix} `;
        textSpan.appendChild(prefixSpan);
      }

      const contentSpan = document.createElement('span');
      const cursorSpan = document.createElement('span');
      cursorSpan.className = 'typing-cursor';
      cursorSpan.setAttribute('aria-hidden', 'true');

      textSpan.appendChild(contentSpan);
      textSpan.appendChild(cursorSpan);
      row.appendChild(textSpan);

      const tagSpan = document.createElement('span');
      tagSpan.className = 'log-tag';
      tagSpan.textContent = '...';
      row.appendChild(tagSpan);

      this.el.terminalLog.appendChild(row);
      this.el.terminalLog.scrollTop = this.el.terminalLog.scrollHeight;

      for (let i = 0; i < text.length; i += 1) {
        if (!this.isAlive(token)) return;
        contentSpan.textContent += text[i];
        if (i % 4 === 0) {
          this.audio.playDigitalTick();
        }
        const ok = await this.wait(this.scaleMs(charDelayMs), token);
        if (!ok) return;
      }

      cursorSpan.remove();
      tagSpan.textContent = tag;
      this.el.terminalLog.scrollTop = this.el.terminalLog.scrollHeight;
    }

    triggerGlitchBurst(durationMs = 240) {
      if (!this.el.appShell) return;
      document.body.classList.add('is-glitching');
      this.el.appShell.classList.add('is-distorted');

      this.schedule(() => {
        document.body.classList.remove('is-glitching');
        this.el.appShell.classList.remove('is-distorted');
      }, durationMs);
    }

    async start(startStage = 1) {
      this.runToken += 1;
      const token = this.runToken;
      this.clearTimers();
      this.resetUI();

      if (startStage === 2) {
        await this.jumpPrepareStage2(token);
        return this.runStage2(token);
      }
      if (startStage === 3) {
        return this.runStage3(token, false);
      }
      if (startStage === 4) {
        return this.runStage4(token);
      }
      if (startStage === 5) {
        return this.runStage5(token, false);
      }

      return this.runStage1(token);
    }

    async jumpPrepareStage2(token) {
      this.showOnlyStage('terminal');
      this.setPhase('init', 1);
      STAGE_1_LINES.forEach((line) => {
        const row = document.createElement('div');
        row.className = 'log-line';

        const textSpan = document.createElement('span');
        textSpan.className = 'log-line-text';

        const prefixSpan = document.createElement('span');
        prefixSpan.className = 'log-prefix';
        prefixSpan.textContent = `${line.prefix} `;

        const contentSpan = document.createElement('span');
        contentSpan.textContent = line.text;

        const tagSpan = document.createElement('span');
        tagSpan.className = 'log-tag';
        tagSpan.textContent = line.tag;

        textSpan.appendChild(prefixSpan);
        textSpan.appendChild(contentSpan);
        row.appendChild(textSpan);
        row.appendChild(tagSpan);
        this.el.terminalLog.appendChild(row);
      });
      this.setProgress(44);
      await this.wait(this.scaleMs(150), token);
    }

    async runStage1(token) {
      this.showOnlyStage('terminal');
      this.setPhase('init', 1);
      this.el.statusPill.textContent = 'INITIALIZING...';
      this.el.progressCaption.textContent = 'BOOT SEQUENCE ACTIVE';

      if (!(await this.wait(this.scaleMs(320), token))) return;

      let currentPct = 0;
      const pctSteps = [9, 18, 27, 36, 44];

      for (let i = 0; i < STAGE_1_LINES.length; i += 1) {
        if (!this.isAlive(token)) return;
        const line = STAGE_1_LINES[i];
        const nextPct = pctSteps[i];
        const progressPromise = this.animateProgressTo(currentPct, nextPct, this.scaleMs(620), token);
        await this.appendTypedLine(line, 18, token);
        await progressPromise;
        currentPct = nextPct;
        if (!(await this.wait(this.scaleMs(210), token))) return;
      }

      if (this.isAlive(token)) {
        await this.runStage2(token);
      }
    }

    async runStage2(token) {
      this.showOnlyStage('terminal');
      this.setPhase('scanning', 2);
      this.el.statusPill.textContent = 'ACTIVE SCAN';
      this.el.progressCaption.textContent = 'SIMULATED ENVIRONMENT DIAGNOSTICS';

      let currentPct = 44;

      for (let i = 0; i < STAGE_2_STEPS.length; i += 1) {
        if (!this.isAlive(token)) return;
        const step = STAGE_2_STEPS[i];

        if (!(await this.wait(this.scaleMs(step.delayBefore), token))) return;
        if (!this.isAlive(token)) return;

        const nodeVal = document.getElementById(step.nodeId);
        if (nodeVal) {
          nodeVal.textContent = step.activeLabel;
          nodeVal.parentElement.classList.add('is-active');
        }

        this.audio.playScanBeep();
        if (i === 2) {
          this.triggerGlitchBurst(200);
        }

        const progressPromise = this.animateProgressTo(
          currentPct,
          step.targetProgress,
          this.scaleMs(step.holdAfter + 380),
          token
        );

        await this.appendTypedLine(
          { prefix: '[>>]', text: step.text, tag: step.tag, isScan: true },
          20,
          token
        );
        await progressPromise;
        currentPct = step.targetProgress;

        if (nodeVal) {
          nodeVal.textContent = step.doneLabel;
          nodeVal.parentElement.classList.remove('is-active');
          nodeVal.parentElement.classList.add('is-done');
        }

        if (!(await this.wait(this.scaleMs(step.holdAfter), token))) return;
      }

      if (this.isAlive(token)) {
        await this.runStage3(token, true);
      }
    }

    async runStage3(token, withBlackout = true) {
      if (withBlackout) {
        this.el.fxBlackout.classList.add('is-blackout');
        if (!(await this.wait(this.scaleMs(360), token))) return;
      }

      this.showOnlyStage('warning');
      this.setPhase('warning', 3);
      this.el.fxBlackout.classList.remove('is-blackout');
      this.triggerGlitchBurst(280);

      for (let sec = 10; sec >= 0; sec -= 1) {
        if (!this.isAlive(token)) return;

        this.el.countdownNumber.textContent = String(sec);
        this.el.countdownNumber.classList.remove('is-tick');
        // Force reflow so the pulse animation retriggers cleanly each second
        void this.el.countdownNumber.offsetWidth;
        this.el.countdownNumber.classList.add('is-tick');

        const elapsedFraction = (10 - sec) / 10;
        const offset = DIAL_CIRCUMFERENCE * elapsedFraction;
        this.el.countdownArc.style.strokeDashoffset = offset.toFixed(2);

        const tickerIdx = Math.min(
          WARNING_TICKERS.length - 1,
          Math.floor((10 - sec) / 3)
        );
        this.el.warningTickerText.textContent = WARNING_TICKERS[tickerIdx];

        this.audio.playWarningAlarm(sec);

        if (sec === 7 || sec === 4 || sec === 2) {
          this.triggerGlitchBurst(220);
        }

        const tickDuration = sec === 0 ? this.scaleMs(520) : this.scaleMs(1000);
        if (!(await this.wait(tickDuration, token))) return;
      }

      if (this.isAlive(token)) {
        await this.runStage4(token);
      }
    }

    async runStage4(token) {
      this.showOnlyStage('breach');
      this.setPhase('breach', 4);
      this.audio.playBreachImpact();
      this.triggerGlitchBurst(320);

      if (!(await this.wait(this.scaleMs(1150), token))) return;

      this.el.breachAlert.classList.add('is-visible');
      this.triggerGlitchBurst(260);

      if (!(await this.wait(this.scaleMs(2150), token))) return;

      if (this.isAlive(token)) {
        await this.runStage5(token, true);
      }
    }

    async runStage5(token, withFlash = true) {
      if (withFlash) {
        this.el.fxBlackout.classList.add('is-white-flash');
        if (!(await this.wait(this.scaleMs(220), token))) return;
      }

      this.showOnlyStage('reveal');
      this.setPhase('reveal', 5);
      this.el.fxBlackout.classList.remove('is-white-flash');

      this.audio.playRevealFanfare();
      this.effects.launchConfetti(75);
    }

    bindRevealEvents() {
      if (this.el.btnGotMe) {
        this.el.btnGotMe.addEventListener('click', () => {
          this.hasCelebrated = true;
          this.el.btnGotMe.classList.add('is-celebrated');
          this.el.btnGotMeText.textContent = 'GLAD YOU LAUGHED! 🎉';
          this.el.revealPostNote.textContent = '100% harmless — zero files, data, or network touched!';
          this.el.revealPostNote.classList.add('is-visible');

          this.el.revealEmojiRing.classList.remove('is-bouncing');
          void this.el.revealEmojiRing.offsetWidth;
          this.el.revealEmojiRing.classList.add('is-bouncing');

          this.audio.playCelebrationPop();
          this.effects.launchConfetti(95);
        });
      }

      if (this.el.btnReplay) {
        this.el.btnReplay.addEventListener('click', () => {
          this.start(1);
        });
      }

      if (this.el.btnShare) {
        this.el.btnShare.addEventListener('click', async () => {
          const shareUrl = global.location.href.split('?')[0];
          const labelEl = this.el.btnShareLabel;

          try {
            if (navigator.share) {
              await navigator.share({
                title: 'NIGHTMARE',
                text: 'Check out this link 👀',
                url: shareUrl
              });
              return;
            }
            if (navigator.clipboard && navigator.clipboard.writeText) {
              await navigator.clipboard.writeText(shareUrl);
              labelEl.textContent = 'Link Copied!';
              this.schedule(() => {
                labelEl.textContent = 'Copy Prank Link';
              }, 2200);
              return;
            }
          } catch (_) {
            // User canceled share or clipboard denied
          }

          this.el.revealPostNote.textContent = `Share URL: ${shareUrl}`;
          this.el.revealPostNote.classList.add('is-visible');
        });
      }
    }
  }

  global.NightmareExperience = NightmareExperience;
})(window);
