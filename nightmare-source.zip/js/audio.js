/**
 * NIGHTMARE — Procedural Web Audio Engine
 * Strictly user-gesture initiated; zero external audio files required.
 */
(function (global) {
  'use strict';

  class AudioEngine {
    constructor() {
      this.ctx = null;
      this.masterGain = null;
      this.ambienceNodes = null;
      this.isEnabled = false;
      this.currentStage = 1;
    }

    /**
     * Must only be called from a direct user gesture (click / tap / keydown).
     */
    async enable() {
      const AudioCtx = global.AudioContext || global.webkitAudioContext;
      if (!AudioCtx) {
        this.isEnabled = false;
        return false;
      }

      if (!this.ctx) {
        this.ctx = new AudioCtx();
        this.masterGain = this.ctx.createGain();
        this.masterGain.gain.value = 0.0001;
        this.masterGain.connect(this.ctx.destination);
      }

      if (this.ctx.state === 'suspended') {
        await Promise.race([
          this.ctx.resume(),
          new Promise((resolve) => global.setTimeout(resolve, 200))
        ]);
      }

      this.isEnabled = true;
      const now = this.ctx.currentTime;
      this.masterGain.gain.cancelScheduledValues(now);
      this.masterGain.gain.setValueAtTime(Math.max(this.masterGain.gain.value, 0.0001), now);
      this.masterGain.gain.exponentialRampToValueAtTime(0.45, now + 0.18);

      if (this.currentStage < 5) {
        this.startAmbience();
      }
      return true;
    }

    disable() {
      this.isEnabled = false;
      if (!this.ctx || !this.masterGain) return;

      const now = this.ctx.currentTime;
      this.masterGain.gain.cancelScheduledValues(now);
      this.masterGain.gain.setValueAtTime(Math.max(this.masterGain.gain.value, 0.0001), now);
      this.masterGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.15);
      this.stopAmbience();
    }

    async toggle() {
      if (this.isEnabled) {
        this.disable();
        return false;
      }
      return this.enable();
    }

    setStage(stageNumber) {
      this.currentStage = stageNumber;
      if (!this.isEnabled) return;

      if (stageNumber >= 5) {
        this.stopAmbience();
      } else {
        this.startAmbience();
      }
    }

    startAmbience() {
      if (!this.isEnabled || !this.ctx || this.ambienceNodes) return;

      const now = this.ctx.currentTime;
      const droneGain = this.ctx.createGain();
      droneGain.gain.setValueAtTime(0.0001, now);
      droneGain.gain.exponentialRampToValueAtTime(0.18, now + 0.8);

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(160, now);

      const subOsc = this.ctx.createOscillator();
      subOsc.type = 'sine';
      subOsc.frequency.setValueAtTime(52, now);

      const midOsc = this.ctx.createOscillator();
      midOsc.type = 'triangle';
      midOsc.frequency.setValueAtTime(104.5, now);

      const lfo = this.ctx.createOscillator();
      lfo.type = 'sine';
      lfo.frequency.setValueAtTime(0.28, now);

      const lfoGain = this.ctx.createGain();
      lfoGain.gain.setValueAtTime(48, now);

      lfo.connect(lfoGain);
      lfoGain.connect(filter.frequency);

      subOsc.connect(filter);
      midOsc.connect(filter);
      filter.connect(droneGain);
      droneGain.connect(this.masterGain);

      subOsc.start(now);
      midOsc.start(now);
      lfo.start(now);

      this.ambienceNodes = { droneGain, subOsc, midOsc, lfo };
    }

    stopAmbience() {
      if (!this.ambienceNodes || !this.ctx) return;
      const { droneGain, subOsc, midOsc, lfo } = this.ambienceNodes;
      const now = this.ctx.currentTime;

      try {
        droneGain.gain.cancelScheduledValues(now);
        droneGain.gain.setValueAtTime(Math.max(droneGain.gain.value, 0.0001), now);
        droneGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.25);
        subOsc.stop(now + 0.3);
        midOsc.stop(now + 0.3);
        lfo.stop(now + 0.3);
      } catch (_) {
        // Ignore already-stopped oscillators
      }
      this.ambienceNodes = null;
    }

    playDigitalTick() {
      if (!this.isEnabled || !this.ctx) return;
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(1320, now);
      osc.frequency.exponentialRampToValueAtTime(1760, now + 0.03);

      gain.gain.setValueAtTime(0.045, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.045);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(now);
      osc.stop(now + 0.05);
    }

    playScanBeep() {
      if (!this.isEnabled || !this.ctx) return;
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(760, now);
      osc.frequency.exponentialRampToValueAtTime(590, now + 0.14);

      gain.gain.setValueAtTime(0.09, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.18);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(now);
      osc.stop(now + 0.2);
    }

    playWarningAlarm(secondsRemaining) {
      if (!this.isEnabled || !this.ctx) return;
      const now = this.ctx.currentTime;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(1400, now);

      const oscA = this.ctx.createOscillator();
      const oscB = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      const urgencyBoost = secondsRemaining <= 3 ? 1.16 : 1;
      oscA.type = 'sawtooth';
      oscA.frequency.setValueAtTime(440 * urgencyBoost, now);
      oscA.frequency.linearRampToValueAtTime(360 * urgencyBoost, now + 0.26);

      oscB.type = 'sine';
      oscB.frequency.setValueAtTime(554 * urgencyBoost, now);
      oscB.frequency.linearRampToValueAtTime(466 * urgencyBoost, now + 0.26);

      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.exponentialRampToValueAtTime(0.16, now + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.32);

      oscA.connect(filter);
      oscB.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);

      oscA.start(now);
      oscB.start(now);
      oscA.stop(now + 0.34);
      oscB.stop(now + 0.34);
    }

    playBreachImpact() {
      if (!this.isEnabled || !this.ctx) return;
      const now = this.ctx.currentTime;

      // Sub impact drop
      const sub = this.ctx.createOscillator();
      const subGain = this.ctx.createGain();
      sub.type = 'sine';
      sub.frequency.setValueAtTime(150, now);
      sub.frequency.exponentialRampToValueAtTime(34, now + 0.65);

      subGain.gain.setValueAtTime(0.36, now);
      subGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.78);

      sub.connect(subGain);
      subGain.connect(this.masterGain);
      sub.start(now);
      sub.stop(now + 0.8);

      // Dramatic dissonant alert chord
      [220, 233.08, 311.13].forEach((freq) => {
        const osc = this.ctx.createOscillator();
        const filter = this.ctx.createBiquadFilter();
        const gain = this.ctx.createGain();

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(freq, now);
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(950, now);

        gain.gain.setValueAtTime(0.0001, now);
        gain.gain.exponentialRampToValueAtTime(0.09, now + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 1.1);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.masterGain);
        osc.start(now);
        osc.stop(now + 1.15);
      });
    }

    playRevealFanfare() {
      if (!this.isEnabled || !this.ctx) return;
      const now = this.ctx.currentTime;
      const notes = [523.25, 659.25, 783.99, 1046.5, 1318.5];

      notes.forEach((freq, idx) => {
        const start = now + idx * 0.075;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, start);

        gain.gain.setValueAtTime(0.0001, start);
        gain.gain.exponentialRampToValueAtTime(0.16, start + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.42);

        osc.connect(gain);
        gain.connect(this.masterGain);
        osc.start(start);
        osc.stop(start + 0.45);
      });
    }

    playCelebrationPop() {
      if (!this.isEnabled || !this.ctx) return;
      const now = this.ctx.currentTime;

      // Playful upward pop
      const pop = this.ctx.createOscillator();
      const popGain = this.ctx.createGain();
      pop.type = 'sine';
      pop.frequency.setValueAtTime(320, now);
      pop.frequency.exponentialRampToValueAtTime(880, now + 0.08);
      popGain.gain.setValueAtTime(0.18, now);
      popGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.12);
      pop.connect(popGain);
      popGain.connect(this.masterGain);
      pop.start(now);
      pop.stop(now + 0.14);

      // Sparkle chime
      [783.99, 987.77, 1174.66, 1567.98].forEach((freq, i) => {
        const start = now + 0.05 + i * 0.055;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, start);
        gain.gain.setValueAtTime(0.0001, start);
        gain.gain.exponentialRampToValueAtTime(0.13, start + 0.015);
        gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.34);
        osc.connect(gain);
        gain.connect(this.masterGain);
        osc.start(start);
        osc.stop(start + 0.36);
      });
    }
  }

  global.NightmareAudio = AudioEngine;
})(window);
