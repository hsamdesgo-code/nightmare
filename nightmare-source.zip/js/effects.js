/**
 * NIGHTMARE — Canvas Visual Effects Engine
 * Handles dark telemetry background (Stages 1-4) and playful confetti celebration (Stage 5).
 */
(function (global) {
  'use strict';

  class AmbientEffects {
    constructor(ambientCanvas, confettiCanvas) {
      this.ambientCanvas = ambientCanvas;
      this.ambientCtx = ambientCanvas ? ambientCanvas.getContext('2d') : null;
      this.confettiCanvas = confettiCanvas;
      this.confettiCtx = confettiCanvas ? confettiCanvas.getContext('2d') : null;

      this.mode = 'init'; // 'init' | 'scanning' | 'warning' | 'breach' | 'reveal'
      this.rafId = null;
      this.confettiRafId = null;
      this.particles = [];
      this.confetti = [];
      this.scanAngle = 0;
      this.width = 0;
      this.height = 0;
      this.dpr = 1;
      this.reducedMotion = global.matchMedia && global.matchMedia('(prefers-reduced-motion: reduce)').matches;

      this.handleResize = this.resize.bind(this);
      global.addEventListener('resize', this.handleResize, { passive: true });
      this.resize();
      this.seedParticles();
    }

    resize() {
      this.dpr = Math.min(global.devicePixelRatio || 1, 2);
      this.width = global.innerWidth;
      this.height = global.innerHeight;

      if (this.ambientCanvas && this.ambientCtx) {
        this.ambientCanvas.width = Math.floor(this.width * this.dpr);
        this.ambientCanvas.height = Math.floor(this.height * this.dpr);
        this.ambientCtx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
      }

      if (this.confettiCanvas && this.confettiCtx) {
        this.confettiCanvas.width = Math.floor(this.width * this.dpr);
        this.confettiCanvas.height = Math.floor(this.height * this.dpr);
        this.confettiCtx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
      }
    }

    seedParticles() {
      const count = Math.min(36, Math.max(16, Math.floor((this.width * this.height) / 36000)));
      const glyphs = ['0x7F', 'A9', '10', 'F4', '0x1C', '8E', '01', 'B2'];
      this.particles = Array.from({ length: count }, (_, idx) => ({
        x: Math.random() * this.width,
        y: Math.random() * this.height,
        vy: 0.22 + Math.random() * 0.45,
        alpha: 0.08 + Math.random() * 0.16,
        label: glyphs[idx % glyphs.length]
      }));
    }

    setMode(mode) {
      this.mode = mode;
      if (mode === 'reveal') {
        this.stopAmbient();
      } else {
        this.startAmbient();
      }
    }

    startAmbient() {
      if (this.rafId || !this.ambientCtx) return;
      const tick = () => {
        this.drawAmbientFrame();
        this.rafId = global.requestAnimationFrame(tick);
      };
      this.rafId = global.requestAnimationFrame(tick);
    }

    stopAmbient() {
      if (this.rafId) {
        global.cancelAnimationFrame(this.rafId);
        this.rafId = null;
      }
      if (this.ambientCtx) {
        this.ambientCtx.clearRect(0, 0, this.width, this.height);
      }
    }

    drawAmbientFrame() {
      const ctx = this.ambientCtx;
      if (!ctx) return;

      const w = this.width;
      const h = this.height;
      ctx.clearRect(0, 0, w, h);

      const isAlert = this.mode === 'warning' || this.mode === 'breach';
      const gridAlpha = isAlert ? 0.09 : 0.055;
      const gridSize = w < 600 ? 40 : 54;

      // Subtle tactical grid
      ctx.strokeStyle = isAlert
        ? `rgba(255, 30, 45, ${gridAlpha})`
        : `rgba(143, 10, 18, ${gridAlpha + 0.02})`;
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let x = 0; x <= w; x += gridSize) {
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
      }
      for (let y = 0; y <= h; y += gridSize) {
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
      }
      ctx.stroke();

      // Subtle sweeping radar ring in background
      if (!this.reducedMotion) {
        this.scanAngle = (this.scanAngle + (isAlert ? 0.018 : 0.008)) % (Math.PI * 2);
      }
      const cx = w * 0.5;
      const cy = h * 0.5;
      const radius = Math.min(w, h) * 0.42;

      ctx.save();
      ctx.strokeStyle = isAlert ? 'rgba(255, 30, 45, 0.14)' : 'rgba(255, 30, 45, 0.07)';
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.stroke();

      if (!this.reducedMotion) {
        const beamX = cx + Math.cos(this.scanAngle) * radius;
        const beamY = cy + Math.sin(this.scanAngle) * radius;
        const grad = ctx.createLinearGradient(cx, cy, beamX, beamY);
        grad.addColorStop(0, 'rgba(255, 30, 45, 0)');
        grad.addColorStop(1, isAlert ? 'rgba(255, 30, 45, 0.24)' : 'rgba(46, 242, 123, 0.14)');
        ctx.strokeStyle = grad;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(beamX, beamY);
        ctx.stroke();
      }
      ctx.restore();

      // Drifting simulated hex nodes
      ctx.font = '11px monospace';
      for (let i = 0; i < this.particles.length; i += 1) {
        const p = this.particles[i];
        if (!this.reducedMotion) {
          p.y += p.vy * (isAlert ? 1.8 : 1);
          if (p.y > h + 16) {
            p.y = -12;
            p.x = Math.random() * w;
          }
        }
        ctx.fillStyle = isAlert
          ? `rgba(255, 70, 82, ${p.alpha})`
          : i % 4 === 0
            ? `rgba(46, 242, 123, ${p.alpha})`
            : `rgba(255, 65, 78, ${p.alpha * 0.7})`;
        ctx.fillText(p.label, p.x, p.y);
      }
    }

    launchConfetti(burstCount = 70) {
      if (!this.confettiCtx || this.reducedMotion) return;

      const palette = ['#10b981', '#2563eb', '#f59e0b', '#ec4899', '#8b5cf6', '#06b6d4'];
      const originX = this.width * 0.5;
      const originY = this.height * 0.38;

      for (let i = 0; i < burstCount; i += 1) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 3 + Math.random() * 8.5;
        this.confetti.push({
          x: originX + (Math.random() - 0.5) * 60,
          y: originY + (Math.random() - 0.5) * 30,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed - 4,
          size: 5 + Math.random() * 6,
          rotation: Math.random() * Math.PI * 2,
          vr: (Math.random() - 0.5) * 0.22,
          color: palette[i % palette.length],
          life: 1
        });
      }

      if (!this.confettiRafId) {
        const renderConfetti = () => {
          this.drawConfettiFrame();
          if (this.confetti.length > 0) {
            this.confettiRafId = global.requestAnimationFrame(renderConfetti);
          } else {
            this.confettiRafId = null;
          }
        };
        this.confettiRafId = global.requestAnimationFrame(renderConfetti);
      }
    }

    clearConfetti() {
      this.confetti = [];
      if (this.confettiRafId) {
        global.cancelAnimationFrame(this.confettiRafId);
        this.confettiRafId = null;
      }
      if (this.confettiCtx) {
        this.confettiCtx.clearRect(0, 0, this.width, this.height);
      }
    }

    drawConfettiFrame() {
      const ctx = this.confettiCtx;
      if (!ctx) return;

      ctx.clearRect(0, 0, this.width, this.height);
      for (let i = this.confetti.length - 1; i >= 0; i -= 1) {
        const c = this.confetti[i];
        c.x += c.vx;
        c.y += c.vy;
        c.vy += 0.24; // gentle gravity
        c.vx *= 0.99;
        c.rotation += c.vr;
        c.life -= 0.011;

        if (c.life <= 0 || c.y > this.height + 30) {
          this.confetti.splice(i, 1);
          continue;
        }

        ctx.save();
        ctx.globalAlpha = Math.max(0, c.life);
        ctx.translate(c.x, c.y);
        ctx.rotate(c.rotation);
        ctx.fillStyle = c.color;
        ctx.fillRect(-c.size * 0.5, -c.size * 0.3, c.size, c.size * 0.6);
        ctx.restore();
      }
    }
  }

  global.NightmareEffects = AmbientEffects;
})(window);
